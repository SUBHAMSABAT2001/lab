clear
echo "Enter x:"
read x
echo "Enter y:"
read y
z=$x
x=$y
y=$z
echo "x is $x,y is $y"
