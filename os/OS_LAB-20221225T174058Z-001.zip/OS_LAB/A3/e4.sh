clear 
expr 6 + 3
echo $expr
exit 0
