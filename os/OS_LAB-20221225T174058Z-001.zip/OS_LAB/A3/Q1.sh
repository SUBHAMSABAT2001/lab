clear
echo "Enter name:"
read name
echo "Enter program name:"
read pname
echo "Enter reg.no:"
read rno
echo "Name is $name,program name is $pname,reg no.is $rno"
