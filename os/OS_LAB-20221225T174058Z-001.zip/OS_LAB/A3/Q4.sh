clear
z=`expr $1 + $2`
y=`expr $1 \* $2`
x=`expr $1 - $2`
echo $z $x $y
