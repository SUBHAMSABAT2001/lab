#first program
clear
echo "Hello World"
