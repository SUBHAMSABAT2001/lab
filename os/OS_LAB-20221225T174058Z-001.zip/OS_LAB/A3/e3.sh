clear 
name=Arun
echo "My name is $name"
exit 0
