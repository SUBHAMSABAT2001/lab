clear
echo "Enter a number:"
read n
read d
x=`expr $n / $d`


