clear
echo "Enter a 5-digit number:"
read n

