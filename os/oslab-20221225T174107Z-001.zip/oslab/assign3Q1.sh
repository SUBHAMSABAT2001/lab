echo "Enter your name:-"
read name
echo "Enter your Program Name:-"
read program
echo "Enter you Sic:-"
read sicno
echo "Your name is $name. Your program name is $program. Your sicno is $sicno"
