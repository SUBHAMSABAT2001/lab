# this is swap two number
echo "Enter two numbers"
read x
read y
z=$x
x=$y
y=$z
echo "x is :- $x and y is :- $y"
