#this is read statement example
echo "Your friend name please:"
read fname
echo "Hello $fname, let be friend."
