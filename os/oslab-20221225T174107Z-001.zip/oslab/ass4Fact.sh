# this is program to find the factorial of the number
echo " Enter the number:- "
read x

while [$x -ge 0 ]
