z=`expr $1 + $2`
mul=`expr $1 \* $2`
sub=`expr $1 - $2`
echo "sum is :- $z"
echo "product is :- $mul"
echo "diff is :- $sub"
