# the program to determine the number is even or odd
echo "Enter the two numbers:-"
read
