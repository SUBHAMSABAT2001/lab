# this is program to find the odd position digit
echo "Enter the number:-"

