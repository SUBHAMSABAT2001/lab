# this is second program
clear
$name = "Sibasish"
echo "Username is :- $name"
