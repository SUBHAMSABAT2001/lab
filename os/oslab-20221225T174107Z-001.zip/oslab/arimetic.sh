x=3
y=1
z=`expr $x + $y`
echo $z
