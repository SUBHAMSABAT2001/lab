# this is second program
clear
name=sibasish
echo "Username is $name"
