# This is first script file
clear
echo "First script program"
